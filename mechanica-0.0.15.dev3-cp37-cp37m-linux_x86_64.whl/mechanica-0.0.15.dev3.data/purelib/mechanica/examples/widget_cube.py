import mechanica as m
from ipywidgets import widgets

m.Simulator(windowless=True, window_size=[1024,1024])

# dimensions of universe
dim=[10., 10., 10.]

c = m.Cuboid(pos=m.Universe.center + [1, 1, 1])

w = widgets.Image(value=m.system.image_data(), width=600)

display(w)





